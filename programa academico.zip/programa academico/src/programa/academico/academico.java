package programa.academico;       
public class academico {
    protected String Codigo;
    protected String Nombre;

    public academico(String Codigo, String Nombre) {
        this.Codigo = Codigo;
        this.Nombre = Nombre;
    }
    public void mostrarinfo() {
        System.out.println("codigo: " + Codigo + ", nombre: " + Nombre);
}
}
