package programa.academico;
import java.util.ArrayList;
import java.util.List;
public class programa extends academico {
    private int duracion;
    private List<Curso> cursos; 

    public programa(String Codigo, String Nombre) {
        super(Codigo, Nombre);
        this.duracion = duracion;
        this.cursos = new ArrayList<>();
    }
    public void agregarcurso(Curso curso) {
        cursos.add(curso);
    }
    public void mostrarprograma (){
        super.mostrarinfo();
        System.out.println("duracion: "+ duracion + "meses");
        System.out.println("cursos en el programa");
        for (Curso c: cursos){
            c.mostrarcurso();
            System.out.println("-------------------------------------");
        }
    }
    }

