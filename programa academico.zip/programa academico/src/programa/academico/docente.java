package programa.academico;
public class docente {
    private String nombre;
    private String Especialidad;

    public docente(String Nombre, String Especialidad) {
        this.nombre = Nombre;
        this.Especialidad = Especialidad;
    }
    public void mostrarinfo() {
        System.out.println("especialidad: " + Especialidad + ", docente: " + nombre);
    }

            }
