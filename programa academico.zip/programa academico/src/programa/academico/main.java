package programa.academico;
public class main {
    public static void main(String[] args) {
        docente d1 = new docente ("juan lopez", "calculo 1");
        docente d2 = new docente ("maria perez", "POO");
        Curso c1 = new Curso ("c3278", "matematica", 4);
        Curso c2 = new Curso ("c3278", "programacion", 5);
        c1.asignarDocente(d1);
        c2.asignarDocente(d2);
        estudiante e1 = new estudiante ("carlos creus", "u378378");
        estudiante e2 = new estudiante ("ana garcia", "u303562");
        estudiante e3 = new estudiante ("javier gomez", "u320831");
        c1 .inscirbirEstudiante(e1);
        c1 .inscirbirEstudiante(e2);
        c2 .inscirbirEstudiante(e3);
        c2 .inscirbirEstudiante(e2);
        programa programa = new programa("p001 ", "ingenieria de sistemas");
        programa.agregarcurso(c1);
        programa.agregarcurso(c2);
        programa.mostrarprograma();
    }
    
}
