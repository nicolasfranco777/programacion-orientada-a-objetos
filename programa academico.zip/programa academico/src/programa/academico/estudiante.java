package programa.academico;
public class estudiante {
    private String Nombre;
    private String matricula;

    public estudiante(String Nombre, String matricula) {
        this.Nombre = Nombre;
        this.matricula = matricula;
    }
    public void mostrarestudiante() {
        System.out.println("matricula: " + matricula + ", nombre: " + Nombre);
    }

            }
