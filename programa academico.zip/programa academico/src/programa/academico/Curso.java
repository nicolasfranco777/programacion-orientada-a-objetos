package programa.academico;
import java.util.ArrayList;
import java.util.List;
public class Curso extends academico{
    private int creditos;
    private docente Docente;
    private List<estudiante> estudiantes;

    public Curso(String Codigo, String Nombre, int creditos) {
        super(Codigo, Nombre);
        this.creditos = creditos;
        this.estudiantes = new ArrayList<>();
    }

    public void asignarDocente (docente Docente) {
        this.Docente = Docente;
        }
    
    public void inscirbirEstudiante (estudiante Estudiante) {
        estudiantes.add(Estudiante);   
    } 
    public void mostrarcurso (){
        super.mostrarinfo();
        System.out.println("Creditos : " + creditos);
        if (Docente !=null) {
            Docente.mostrarinfo();
        }else{
            System.out.println("sin docente");
        }
        if (estudiantes.isEmpty()){
            System.out.println("sin estudiantes");
        }else{
            System.out.println("estudiantes");
            for (estudiante e : estudiantes) {
                e.mostrarestudiante();
            }
        }
    }
}
